import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text('Travel Tips')),
        body: Center(
          child: ElevatedButton(
            onPressed: () {
              launchUrl(Uri.parse('https://www.lonelyplanet.com/'));
            },
            child: Text('Open Travel Tips'),
          ),
        ),
      ),
    );
  }
}
